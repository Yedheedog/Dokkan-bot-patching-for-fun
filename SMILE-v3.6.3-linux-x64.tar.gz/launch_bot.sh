#!/bin/bash
# ========================================
# Dokkan Battle Bot - Unix/Linux/macOS Launcher
# ========================================
# USAGE:
#   1. Give execute permissions: chmod +x launch_bot.sh
#   2. Run the script:           ./launch_bot.sh
#
# Requirements: Python 3.12 (recommended 3.12.10) must be installed.
# The compiled modules are built for CPython 3.12 only - 3.11/3.13/3.14 fail.
#
# NOTE: we deliberately do NOT use 'set -e'. Each step checks its own result
# and prints a clear, specific explanation instead of exiting silently.

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status()  { echo -e "${BLUE}[$1/7]${NC} $2"; }
print_success() { echo -e "${GREEN}OK:${NC} $1"; }
print_error()   { echo -e "${RED}ERROR:${NC} $1"; }
print_warning() { echo -e "${YELLOW}WARNING:${NC} $1"; }

# Anchor to this script's own folder so it works no matter where it was
# launched from (double-click, sudo, a different terminal cwd).
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || { print_error "Could not enter the script folder: $SCRIPT_DIR"; exit 1; }

echo
echo "========================================"
echo "   DOKKAN BATTLE BOT - UNIX LAUNCHER"
echo "========================================"
echo

# ------------------------------------------------------------
print_status "1" "Checking your environment..."
echo "    Folder: $SCRIPT_DIR"

# Running as root? Usually unnecessary and can leave root-owned files behind.
if [ "$(id -u)" -eq 0 ]; then
    print_warning "You are running as root (sudo)."
    echo "    This is normally NOT needed and can create root-owned files that"
    echo "    later break a normal launch. If you hit permission errors, run"
    echo "    the script WITHOUT sudo, from your own user account."
fi

# Running from a temporary / extraction folder?
case "$SCRIPT_DIR" in
    /tmp/*|*/Temp/*|*/.cache/*)
        print_warning "This looks like a temporary folder."
        echo "    If you launched the bot from inside the archive, extract the"
        echo "    FULL archive somewhere permanent (e.g. ~/DokkanBot) and run"
        echo "    launch_bot.sh from there."
        ;;
esac

# Folder inside a cloud-sync location?
case "$SCRIPT_DIR" in
    *OneDrive*|*"Mobile Documents"*|*Dropbox*)
        print_warning "This folder is inside a cloud-sync location."
        echo "    Cloud sync can lock files while the bot runs. If you hit"
        echo "    read/write errors, move the bot to a local folder such as"
        echo "    ~/DokkanBot and run it there."
        ;;
esac

# Are the bot files actually here?
if [ ! -f "requirements.txt" ] && [ ! -f "bot/bot_launcher.py" ] && [ ! -f "bot_launcher.py" ]; then
    print_error "The bot files were not found next to this launcher."
    echo "    Current folder: $SCRIPT_DIR"
    echo "    Extract the FULL archive and run launch_bot.sh from inside the"
    echo "    extracted folder."
    exit 1
fi
print_success "Environment check done"

# ------------------------------------------------------------
echo
print_status "2" "Checking Python installation..."
echo "    The bot needs Python 3.12 (recommended 3.12.10)."
echo "    Python 3.11, 3.13 and 3.14 will NOT work - the compiled files"
echo "    are built for 3.12 only."

PYTHON_CMD=""
if command -v python3.12 >/dev/null 2>&1; then
    PYTHON_CMD="python3.12"
elif command -v python312 >/dev/null 2>&1; then
    PYTHON_CMD="python312"
elif command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_CMD="python"
else
    print_error "Python is not installed or not on PATH."
    echo "    Install Python 3.12.10, then run this launcher again:"
    echo "      https://www.python.org/downloads/release/python-31210/"
    echo "      or:  sudo apt install python3.12   /   brew install python@3.12"
    exit 1
fi

PYTHON_VERSION="$($PYTHON_CMD --version 2>&1 | cut -d' ' -f2)"
echo "    Found Python $PYTHON_VERSION at: $PYTHON_CMD"

MAJOR="$(echo "$PYTHON_VERSION" | cut -d'.' -f1)"
MINOR="$(echo "$PYTHON_VERSION" | cut -d'.' -f2)"
if [ "$MAJOR" != "3" ] || [ "$MINOR" != "12" ]; then
    print_error "Python 3.12 is required for the compiled modules. Found: $PYTHON_VERSION"
    echo "    Install Python 3.12.10 specifically, then run this launcher again:"
    echo "      https://www.python.org/downloads/release/python-31210/"
    echo "      or:  sudo apt install python3.12   /   brew install python@3.12"
    exit 1
fi
print_success "Python 3.12 check passed ($PYTHON_VERSION)"

# ------------------------------------------------------------
echo
print_status "3" "Checking virtual environment..."
if [ ! -d "env" ]; then
    echo "    Creating virtual environment..."
    "$PYTHON_CMD" -m venv env
    if [ $? -ne 0 ]; then
        print_error "Failed to create the virtual environment."
        echo "    - Make sure you have write permission in this folder."
        echo "    - On Debian/Ubuntu you may also need: sudo apt install python3.12-venv"
        echo "    - If an old 'env' exists from another Python, delete it and retry."
        exit 1
    fi
    print_success "Virtual environment created"
else
    print_success "Virtual environment found"
fi

# ------------------------------------------------------------
echo
print_status "4" "Activating virtual environment..."
if [ ! -f "env/bin/activate" ]; then
    print_error "env/bin/activate not found - the 'env' folder is incomplete."
    echo "    Delete the 'env' folder and run this script again."
    exit 1
fi
# shellcheck disable=SC1091
source env/bin/activate
if [ $? -ne 0 ]; then
    print_error "Failed to activate the virtual environment."
    echo "    Delete the 'env' folder and run this script again."
    exit 1
fi
print_success "Virtual environment activated"

# Call the venv's python by ABSOLUTE PATH from here on, so it can't be shadowed
# by a stray "python" elsewhere on PATH.
VENV_PY="$SCRIPT_DIR/env/bin/python"
if [ ! -x "$VENV_PY" ]; then
    print_error "The virtual environment's Python was not found at: $VENV_PY"
    echo "    The 'env' folder is incomplete. Delete it and relaunch this script."
    exit 1
fi

# ------------------------------------------------------------
echo
print_status "5" "Checking dependencies..."
if [ ! -f "requirements.txt" ]; then
    print_warning "requirements.txt not found - skipping dependency install."
else
    echo "    Installing/updating dependencies. This can take a minute..."
    "$VENV_PY" -m pip install --upgrade pip setuptools wheel
    "$VENV_PY" -m pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        print_error "Failed to install dependencies."
        echo "    - Check your internet connection, proxy or firewall."
        echo "    - Re-run the launcher; a partial download often fixes itself."
        echo "    - If the folder is on a cloud drive, move it somewhere local."
        exit 1
    fi
    print_success "Dependencies installed/updated"
fi

# ------------------------------------------------------------
echo
print_status "6" "Checking bot launcher..."
# Support BOTH compiled distribution (bot/bot_launcher.py + main.pyd|.so)
# and source checkout (bot_launcher.py at repo root + src/main.py).
LAUNCHER_LAYOUT=""
if [ -f "bot/bot_launcher.py" ]; then
    LAUNCHER_LAYOUT="compiled"
    print_success "Bot launcher found in bot/ directory (compiled distribution)"
elif [ -f "bot_launcher.py" ]; then
    LAUNCHER_LAYOUT="source"
    print_success "Bot launcher found at repo root (source checkout)"
else
    print_error "bot_launcher.py not found in bot/ or this folder."
    echo "    Extract the FULL archive and run from the extracted folder."
    exit 1
fi

# ------------------------------------------------------------
echo
print_status "7" "Launching bot..."
echo "========================================"
echo "Starting Dokkan Battle Bot..."
echo "========================================"
echo
echo -e "${YELLOW}IMPORTANT:${NC} A Discord authorization page will open in your browser."
echo "Please authorize the application to verify your tier and continue."
echo "The bot will wait for you to complete the authorization..."
echo

if [ "$LAUNCHER_LAYOUT" = "compiled" ]; then
    # Change to bot/ so main.pyd|.so is on sys.path next to bot_launcher.py.
    # VENV_PY is an absolute path, so it still resolves after the cd.
    cd bot
    "$VENV_PY" bot_launcher.py
    EXIT_CODE=$?
else
    # Source checkout: stay at repo root; bot_launcher._resolve_main_dir
    # adds src/ to sys.path before importing main.
    "$VENV_PY" bot_launcher.py
    EXIT_CODE=$?
fi

if [ "$EXIT_CODE" -ne 0 ]; then
    echo
    echo "========================================"
    echo "Bot exited with error code: $EXIT_CODE"
    echo "========================================"
    echo
    echo "If the bot did not start, run down this quick checklist:"
    echo "  1. Python is 3.12 - recommended 3.12.10. Other versions fail."
    echo "  2. The bot folder is NOT inside a cloud-sync or temp folder."
    echo "  3. You are NOT using sudo - run as your normal user."
    echo "  4. The full archive was extracted, not run from inside it."
    echo
fi

echo
echo "Bot session ended."
