"""
This module is used to serialize and deserialize the data into py objects.
"""