from typing import Dict, Type, TypeVar, Union

from pydantic import BaseModel


# A generic type for deserialization
T = TypeVar("T", bound="BaseModelWithDefaults")


class BaseModelWithDefaults(BaseModel):
    """Custom BaseModel that provides defaults for all fields."""

    model_config = {
        "extra": "allow",
        "ignored_types": (type(lambda: None),),  # Ignore function types
    }

    def __init__(self, **data):
        """Set default values for missing data."""
        for field_name, field in self.model_fields.items():
            if field_name not in data:
                if field.annotation == list:
                    data[field_name] = []  # Default for lists
                elif field.annotation == dict:
                    data[field_name] = {}  # Default for dicts
                elif field.annotation == int:
                    data[field_name] = 0  # Default for integers
                elif field.annotation == float:
                    data[field_name] = 0.0  # Default for floats
                elif field.annotation == str:
                    data[field_name] = ""  # Default for strings
                elif field.annotation == bool:
                    data[field_name] = False  # Default for booleans
                else:
                    data[field_name] = None  # Default for other types
        super().__init__(**data)

    def serialize(self) -> Dict:
        """Convert the model instance to a dictionary."""
        return self.model_dump()

    @classmethod
    def deserialize(cls: Type[T], data: Union[Dict, str]) -> T:
        """Create an instance of the model from a dictionary."""
        if isinstance(data, str):
            import json

            data = json.loads(data)
        return cls(**data)
