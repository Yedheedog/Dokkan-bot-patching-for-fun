# src/bot/managers/__init__.py

"""
This package contains specialized manager classes that handle specific aspects
of the bot's interaction with the game, such as card management, team building,
character progression, item inventories, shop interactions, and farming orchestration.
"""

# This __init__.py can be left empty or used to expose specific classes directly
# from the package, e.g.:
# from .card_manager import CardManager
# from .team_manager import TeamManager
# ... and so on.