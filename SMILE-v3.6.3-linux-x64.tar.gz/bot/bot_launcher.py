#!/usr/bin/env python3
"""Bot Launcher - resolves main from either layout.

Two supported layouts:
  - Compiled distribution: ``main.py`` / ``main.pyd`` next to this file
    (cwd typically ``<dist>/bot/`` after launch_bot.* cds into it).
  - Source checkout: this file at repo root, ``src/main.py`` one level
    below. Adds ``src/`` to sys.path before importing.

Calling ``_resolve_main_dir()`` returns the directory to insert into
``sys.path`` and import ``main`` from.
"""

import sys
from pathlib import Path


_MAIN_FILENAMES = ("main.py", "main.pyd")
_MAIN_GLOBS = ("main.*.pyd", "main.*.so")


def _has_main_module(directory: Path) -> bool:
    """Return True when ``directory`` contains a ``main`` module the
    importer can pick up (raw .py, plain .pyd, or a tagged Cython build
    like ``main.cp312-win_amd64.pyd``)."""
    for name in _MAIN_FILENAMES:
        if (directory / name).exists():
            return True
    for pattern in _MAIN_GLOBS:
        if any(directory.glob(pattern)):
            return True
    return False


def _resolve_main_dir() -> Path:
    """Find the directory that holds the ``main`` module.

    Search order:
      1. Same directory as this launcher (compiled distribution).
      2. ``<launcher>/src`` (source checkout).

    Raises FileNotFoundError listing both paths when neither has a
    ``main`` module - actionable diagnostic for a misplaced launcher.
    """
    launcher_dir = Path(__file__).resolve().parent
    candidates = [launcher_dir, launcher_dir / "src"]
    for candidate in candidates:
        if _has_main_module(candidate):
            return candidate
    raise FileNotFoundError(
        "main.py / main.pyd not found. Searched:\n  - "
        + "\n  - ".join(str(c) for c in candidates)
        + "\n\nFor a source checkout, run this launcher from the repo root "
        "(it expects src/main.py).\nFor a compiled distribution, run it from "
        "the bot/ folder beside main.pyd."
    )


def main():
    """Entry point: resolve the main module, add its dir to sys.path, import + run."""
    try:
        main_dir = _resolve_main_dir()
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(1)

    if str(main_dir) not in sys.path:
        sys.path.insert(0, str(main_dir))

    try:
        import main as _main_module
    except ImportError as e:
        print(f"Error: Could not import main from {main_dir}: {e}")
        sys.exit(1)

    if not hasattr(_main_module, "main") or not callable(_main_module.main):
        print("Error: main.main() function not found in resolved module")
        sys.exit(1)

    try:
        _main_module.main()
    except Exception as e:
        print(f"Error: Failed to run bot: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
