import datetime
from typing import Optional

from sqlalchemy import JSON, DateTime, Float, Index, Integer, String, Text, Time, UniqueConstraint, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class AchievementCategories(Base):
    __tablename__ = "achievement_categories"
    __table_args__ = (
        Index("idx_achievement_categories_index_achievement_categories_on_open_at_and_priority", "open_at", "priority"),
        Index("idx_achievement_categories_index_achievement_categories_on_parent_category_id", "parent_category_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    parent_category_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class Achievements(Base):
    __tablename__ = "achievements"
    __table_args__ = (
        Index("idx_achievements_index_achievements_on_achievement_category_id", "achievement_category_id"),
        Index("idx_achievements_index_achievements_on_open_at_and_priority", "open_at", "priority"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    achievement_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    width: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    height: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    text_color: Mapped[int] = mapped_column(Integer, nullable=False)
    frame_image_name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_name_hidden: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    link_to: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class ActCureSchedules(Base):
    __tablename__ = "act_cure_schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    seconds_per_cure_one_act: Mapped[int] = mapped_column(Integer, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ActItems(Base):
    __tablename__ = "act_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    recover_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ActiveSkillSets(Base):
    __tablename__ = "active_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    effect_description: Mapped[str] = mapped_column(Text, nullable=False)
    condition_description: Mapped[str] = mapped_column(Text, nullable=False)
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exec_limit: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    costume_special_view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    ultimate_special_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    special_view_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ActiveSkills(Base):
    __tablename__ = "active_skills"
    __table_args__ = (Index("idx_active_skills_index_active_skills_on_active_skill_set_id", "active_skill_set_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    active_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_val1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_val2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_val3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    sub_target_type_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    thumb_effect_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    effect_se_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class AreaConditions(Base):
    __tablename__ = "area_conditions"
    __table_args__ = (Index("idx_area_conditions_index_area_conditions_on_area_id", "area_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    area_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    comment: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class AreaRecommends(Base):
    __tablename__ = "area_recommends"
    __table_args__ = (
        Index("idx_area_recommends_index_area_recommends_on_area_id", "area_id"),
        Index("idx_area_recommends_index_area_recommends_on_rank_range_id", "rank_range_id"),
        Index("idx_area_recommends_index_area_recommends_on_rank_range_id_and_area_id", "rank_range_id", "area_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    area_id: Mapped[int] = mapped_column(Integer, nullable=False)
    rank_range_id: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class AreaTabs(Base):
    __tablename__ = "area_tabs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    limited: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    area_category_ids: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class Areas(Base):
    __tablename__ = "areas"
    __table_args__ = (
        Index("idx_areas_index_areas_on_announcement_id", "announcement_id"),
        Index("idx_areas_index_areas_on_chapter_id", "chapter_id"),
        Index("idx_areas_index_areas_on_event_priority", "event_priority"),
        Index("idx_areas_index_areas_on_prev_area_id", "prev_area_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    is_listbutton_visible: Mapped[int] = mapped_column(Integer, nullable=False)
    event_priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_quest_num_visible: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    category: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    chapter_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    db_story_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    prev_area_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    all_clear_bonus_stones: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    event_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    banner_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    listbutton_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    announcement_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    first_released_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, server_default=text("NULL"))
    mission_difficulty: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class AwakeningItems(Base):
    __tablename__ = "awakening_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    zeni: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    event_jumpable: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'1'"))


class BattleParams(Base):
    __tablename__ = "battle_params"
    __table_args__ = (Index("idx_battle_params_index_battle_params_on_param_no", "param_no"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    param_no: Mapped[int] = mapped_column(Integer, nullable=False)
    idx: Mapped[int] = mapped_column(Integer, nullable=False)
    value: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BgmSchedules(Base):
    __tablename__ = "bgm_schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bgm_id: Mapped[int] = mapped_column(Integer, nullable=False)
    scene_name: Mapped[str] = mapped_column(String(255), nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BoostSchedules(Base):
    __tablename__ = "boost_schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    max_point: Mapped[int] = mapped_column(Integer, nullable=False)
    seconds_per_cure_one_point: Mapped[int] = mapped_column(Integer, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiBoxRankingRewardRanges(Base):
    __tablename__ = "budokai_box_ranking_reward_ranges"
    __table_args__ = (
        Index("idx_budokai_box_ranking_reward_ranges_index_budokai_box_ranking_reward_ranges", "budokai_box_ranking_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_box_ranking_id: Mapped[int] = mapped_column(Integer, nullable=False)
    start_value: Mapped[int] = mapped_column(Integer, nullable=False)
    end_value: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiBoxRankingRewards(Base):
    __tablename__ = "budokai_box_ranking_rewards"
    __table_args__ = (
        Index("idx_budokai_box_ranking_rewards_index_budokai_box_ranking_rewards", "budokai_box_ranking_reward_range_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_box_ranking_reward_range_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    gift_description: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiBoxRankings(Base):
    __tablename__ = "budokai_box_rankings"
    __table_args__ = (Index("idx_budokai_box_rankings_index_budokai_box_rankings_on_budokai_id", "budokai_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    player_max_count: Mapped[int] = mapped_column(Integer, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    collecting_end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    prev_budokai_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    prev_budokai_box_ranking_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    box_max_count: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class BudokaiHelpBodies(Base):
    __tablename__ = "budokai_help_bodies"
    __table_args__ = (Index("idx_budokai_help_bodies_index_budokai_help_bodies_on_budokai_help_id", "budokai_help_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    budokai_help_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class BudokaiHelpCategories(Base):
    __tablename__ = "budokai_help_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class BudokaiHelps(Base):
    __tablename__ = "budokai_helps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_help_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class BudokaiLeagues(Base):
    __tablename__ = "budokai_leagues"
    __table_args__ = (UniqueConstraint("budokai_id", "league"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    league: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiMissionRewards(Base):
    __tablename__ = "budokai_mission_rewards"
    __table_args__ = (
        Index("idx_budokai_mission_rewards_index_budokai_mission_rewards_on_budokai_mission_id", "budokai_mission_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_mission_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    gift_description: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiMissions(Base):
    __tablename__ = "budokai_missions"
    __table_args__ = (
        Index("idx_budokai_missions_index_budokai_missions_on_budokai_id_and_mission_type", "budokai_id", "mission_type"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    mission_type: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    target_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    prev_budokai_mission_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class BudokaiMotivationUnlockConditions(Base):
    __tablename__ = "budokai_motivation_unlock_conditions"
    __table_args__ = (
        Index("idx_budokai_motivation_unlock_conditions_index_budokai_motivation_id", "budokai_motivation_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_motivation_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class BudokaiMotivations(Base):
    __tablename__ = "budokai_motivations"
    __table_args__ = (Index("idx_budokai_motivations_index_budokai_motivations_on_budokai_id", "budokai_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    player_description: Mapped[str] = mapped_column(String(255), nullable=False)
    additional_hp_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    max_hp_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    additional_atk_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    max_atk_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    additional_def_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    max_def_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    additional_point_percent: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    announcer_description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class BudokaiOpponentAttackWeightLines(Base):
    __tablename__ = "budokai_opponent_attack_weight_lines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_opponent_attack_weight_id: Mapped[int] = mapped_column(Integer, nullable=False)
    ball_count: Mapped[int] = mapped_column(Integer, nullable=False)
    rate: Mapped[int] = mapped_column(Integer, nullable=False)


class BudokaiOpponentAttackWeights(Base):
    __tablename__ = "budokai_opponent_attack_weights"
    __table_args__ = (UniqueConstraint("budokai_id", "round"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    round: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiProgressSelifs(Base):
    __tablename__ = "budokai_progress_selifs"
    __table_args__ = (UniqueConstraint("budokai_id", "round"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    round: Mapped[int] = mapped_column(Integer, nullable=False)
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class BudokaiRankingGiftSets(Base):
    __tablename__ = "budokai_ranking_gift_sets"
    __table_args__ = (UniqueConstraint("budokai_id", "order"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    order: Mapped[int] = mapped_column(Integer, nullable=False)
    ranking: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class BudokaiRankingGifts(Base):
    __tablename__ = "budokai_ranking_gifts"
    __table_args__ = (
        Index(
            "idx_budokai_ranking_gifts_index_budokai_ranking_gifts_on_budokai_ranking_gift_set_id",
            "budokai_ranking_gift_set_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_ranking_gift_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class BudokaiRanks(Base):
    __tablename__ = "budokai_ranks"
    __table_args__ = (UniqueConstraint("budokai_id", "rank"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    budokai_id: Mapped[int] = mapped_column(Integer, nullable=False)
    budokai_league_id: Mapped[int] = mapped_column(Integer, nullable=False)
    rank: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    point: Mapped[int] = mapped_column(Integer, nullable=False)
    bonus: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class Budokais(Base):
    __tablename__ = "budokais"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    collecting_end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    result_end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    mission_reward_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    banner_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    entry_script_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    description_script_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    enable_battle_auto: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    home_banner_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    listbutton_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class CardActiveSkills(Base):
    __tablename__ = "card_active_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    active_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardAwakeningRoutes(Base):
    __tablename__ = "card_awakening_routes"
    __table_args__ = (
        Index("idx_card_awakening_routes_index_card_awakening_routes_on_awaked_card_id", "awaked_card_id"),
        Index("idx_card_awakening_routes_index_card_awakening_routes_on_card_awakening_set_id", "card_awakening_set_id"),
        Index("idx_card_awakening_routes_index_card_awakening_routes_on_card_id", "card_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_awakening_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    optimal_awakening_type: Mapped[int] = mapped_column(Integer, nullable=False)
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    awaked_card_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    optimal_awakening_step: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)
    priority: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'0'"))


class CardAwakeningSets(Base):
    __tablename__ = "card_awakening_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(60), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(120), server_default=text("NULL"))


class CardAwakenings(Base):
    __tablename__ = "card_awakenings"
    __table_args__ = (Index("idx_card_awakenings_index_card_awakenings_on_card_awakening_set_id", "card_awakening_set_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    awakening_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    card_awakening_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class CardCardCategories(Base):
    __tablename__ = "card_card_categories"
    __table_args__ = (
        Index("idx_card_card_categories_index_card_card_categories_on_card_category_id", "card_category_id"),
        Index(
            "idx_card_card_categories_index_card_card_categories_on_card_id_and_card_category_id",
            "card_id",
            "card_category_id",
        ),
        Index("idx_card_card_categories_index_card_card_categories_on_card_id_and_num", "card_id", "num"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    num: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardCategories(Base):
    __tablename__ = "card_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    kana: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class CardCostumeConditions(Base):
    __tablename__ = "card_costume_conditions"
    __table_args__ = (Index("idx_card_costume_conditions_index_card_costume_conditions_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_costume_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    counter_script_no: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    revival_view_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class CardCostumes(Base):
    __tablename__ = "card_costumes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardDecorations(Base):
    __tablename__ = "card_decorations"
    __table_args__ = (Index("idx_card_decorations_index_card_decorations_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardExps(Base):
    __tablename__ = "card_exps"
    __table_args__ = (
        UniqueConstraint("exp_total", "lv", "exp_type"),
        UniqueConstraint("exp_type", "exp_total"),
        UniqueConstraint("lv", "exp_type"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lv: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exp_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exp_total: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardFinishSkillSetRelations(Base):
    __tablename__ = "card_finish_skill_set_relations"
    __table_args__ = (Index("idx_card_finish_skill_set_relations_index_finish_skill_relations_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    finish_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardGrowths(Base):
    __tablename__ = "card_growths"
    __table_args__ = (UniqueConstraint("grow_type", "lv"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    grow_type: Mapped[int] = mapped_column(Integer, nullable=False)
    lv: Mapped[int] = mapped_column(Integer, nullable=False)
    coef: Mapped[float] = mapped_column(Float, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardMotions(Base):
    __tablename__ = "card_motions"
    __table_args__ = (UniqueConstraint("card_id", "category", "filename"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    category: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    filename: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class CardSkinEffectDetails(Base):
    __tablename__ = "card_skin_effect_details"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    card_skin_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    text_effect_id: Mapped[int] = mapped_column(Integer, nullable=False)
    voice_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardSkinItems(Base):
    __tablename__ = "card_skin_items"
    __table_args__ = (UniqueConstraint("card_id", "step"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    step: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    link_to: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class CardSpecials(Base):
    __tablename__ = "card_specials"
    __table_args__ = (Index("idx_card_specials_index_card_specials_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    special_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    style: Mapped[str] = mapped_column(String(255), nullable=False)
    lv_start: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eball_num_start: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'12'"))
    view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_costume_condition_id: Mapped[int] = mapped_column(Integer, nullable=False)
    special_bonus_id1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_bonus_lv1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bonus_view_id1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_bonus_id2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_bonus_lv2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bonus_view_id2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    detail_view_priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    priority: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    special_asset_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class CardStandbySkillSetRelations(Base):
    __tablename__ = "card_standby_skill_set_relations"
    __table_args__ = (Index("idx_card_standby_skill_set_relations_index_standby_skill_relations_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    standby_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardStickerDecorationRelations(Base):
    __tablename__ = "card_sticker_decoration_relations"
    __table_args__ = (UniqueConstraint("card_sticker_item_id", "card_decoration_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_sticker_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_decoration_id: Mapped[int] = mapped_column(Integer, nullable=False)
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardStickerItems(Base):
    __tablename__ = "card_sticker_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardTrainingFieldExpUpProbs(Base):
    __tablename__ = "card_training_field_exp_up_probs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    effect: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    success_prob_percent: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardTrainingSkillLvUpProbs(Base):
    __tablename__ = "card_training_skill_lv_up_probs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rarity: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    n: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    r: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sr: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    ssr: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    ur: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lr: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))


class CardTrainingSkillLvs(Base):
    __tablename__ = "card_training_skill_lvs"
    __table_args__ = (Index("idx_card_training_skill_lvs_index_card_training_skill_lvs_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    skill_lv: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    condition: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'100'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardUniqueInfoSetRelations(Base):
    __tablename__ = "card_unique_info_set_relations"
    __table_args__ = (UniqueConstraint("card_unique_info_set_id", "card_unique_info_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_unique_info_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_unique_info_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CardUniqueInfos(Base):
    __tablename__ = "card_unique_infos"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    kana: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class Cards(Base):
    __tablename__ = "cards"
    __table_args__ = (
        Index("idx_cards_index_cards_on_leader_skill_set_id", "leader_skill_set_id"),
        Index("idx_cards_index_cards_on_open_at", "open_at"),
        Index("idx_cards_index_cards_on_rarity", "rarity"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    character_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_unique_info_id: Mapped[int] = mapped_column(Integer, nullable=False)
    cost: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    hp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    hp_max: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    atk_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    atk_max: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    def_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    def_max: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    element: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lv_max: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    skill_lv_max: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    grow_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    price: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exp_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    training_exp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_motion: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    eball_mod_min: Mapped[int] = mapped_column(Integer, nullable=False)
    eball_mod_num100: Mapped[int] = mapped_column(Integer, nullable=False)
    eball_mod_mid: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eball_mod_mid_num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eball_mod_max: Mapped[int] = mapped_column(Integer, nullable=False)
    eball_mod_max_num: Mapped[int] = mapped_column(Integer, nullable=False)
    face_x: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    face_y: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_aura_front: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_selling_only: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    optimal_awakening_grow_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    passive_skill_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    leader_skill_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill1_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill2_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill3_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill4_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill5_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill6_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill7_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    max_level_reward_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    max_level_reward_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    collectable_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    aura_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    aura_scale: Mapped[Optional[float]] = mapped_column(Float, server_default=text("NULL"))
    aura_offset_x: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    aura_offset_y: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    awakening_number: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    resource_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    bg_effect_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    awakening_element_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    potential_board_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ChapterProperties(Base):
    __tablename__ = "chapter_properties"
    __table_args__ = (Index("idx_chapter_properties_index_chapter_properties_on_chapter_id", "chapter_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    chapter_id: Mapped[int] = mapped_column(Integer, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    movie_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    thumbnail_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    announcement_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class Chapters(Base):
    __tablename__ = "chapters"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, server_default=text("''"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class Characters(Base):
    __tablename__ = "characters"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    race: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sex: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    size: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ClientSettings(Base):
    __tablename__ = "client_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    value: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    key: Mapped[Optional[str]] = mapped_column(String(255), unique=True, server_default=text("NULL"))


class CollectionCards(Base):
    __tablename__ = "collection_cards"
    __table_args__ = (UniqueConstraint("collection_unique_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    collection_unique_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    event_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class CollectionCategories(Base):
    __tablename__ = "collection_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class CollectionUniques(Base):
    __tablename__ = "collection_uniques"
    __table_args__ = (UniqueConstraint("collection_category_id", "name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    collection_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    background_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DbStories(Base):
    __tablename__ = "db_stories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    banner_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class DialogBodies(Base):
    __tablename__ = "dialog_bodies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)


class Dialogs(Base):
    __tablename__ = "dialogs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dialog_body_ids: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    dialog_icon_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class DokkanFieldActiveSkillSetRelations(Base):
    __tablename__ = "dokkan_field_active_skill_set_relations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dokkan_field_id: Mapped[int] = mapped_column(Integer, nullable=False)
    active_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DokkanFieldEfficacies(Base):
    __tablename__ = "dokkan_field_efficacies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dokkan_field_efficacy_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False)
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False)
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False)
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_once: Mapped[int] = mapped_column(Integer, nullable=False)
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value1: Mapped[int] = mapped_column(Integer, nullable=False)
    eff_value2: Mapped[int] = mapped_column(Integer, nullable=False)
    eff_value3: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class DokkanFieldEfficacySets(Base):
    __tablename__ = "dokkan_field_efficacy_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DokkanFieldPassiveSkillRelations(Base):
    __tablename__ = "dokkan_field_passive_skill_relations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dokkan_field_id: Mapped[int] = mapped_column(Integer, nullable=False)
    passive_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DokkanFields(Base):
    __tablename__ = "dokkan_fields"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dokkan_field_efficacy_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    resource_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DotCharacterGrowths(Base):
    __tablename__ = "dot_character_growths"
    __table_args__ = (UniqueConstraint("grow_type", "lv"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    grow_type: Mapped[int] = mapped_column(Integer, nullable=False)
    lv: Mapped[int] = mapped_column(Integer, nullable=False)
    image_number: Mapped[int] = mapped_column(Integer, nullable=False)
    point_total: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    label_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class DotCharacterLvRewards(Base):
    __tablename__ = "dot_character_lv_rewards"
    __table_args__ = (
        Index(
            "idx_dot_character_lv_rewards_index_dot_character_lv_rewards_on_dot_character_lv_reward_set_id",
            "dot_character_lv_reward_set_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dot_character_lv_reward_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    dot_character_lv: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class DotCharacters(Base):
    __tablename__ = "dot_characters"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    character_number: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    max_lv: Mapped[int] = mapped_column(Integer, nullable=False)
    grow_type: Mapped[int] = mapped_column(Integer, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class EffectPacks(Base):
    __tablename__ = "effect_packs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    pack_name: Mapped[str] = mapped_column(String(255), nullable=False)
    scene_name: Mapped[str] = mapped_column(String(255), nullable=False)
    red: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'255'"))
    green: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'255'"))
    blue: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'255'"))
    alpha: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'255'"))
    lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class EnemyAiConditions(Base):
    __tablename__ = "enemy_ai_conditions"
    __table_args__ = (Index("idx_enemy_ai_conditions_index_enemy_ai_conditions_on_ai_type", "ai_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ai_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    action_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    hp_rate_begin: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    hp_rate_end: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    min_interval: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    max_number: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    atk_rate_1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'100'"))
    atk_rate_2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'100'"))
    recover_hp_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    attack_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'-1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    next_ai_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    ai_param: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    ai_param2: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class EnemyRoundSkillSetRelations(Base):
    __tablename__ = "enemy_round_skill_set_relations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_round_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    enemy_round_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class EnemyRoundSkillSets(Base):
    __tablename__ = "enemy_round_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    effect_description: Mapped[Optional[str]] = mapped_column(Text)
    cancel_description: Mapped[Optional[str]] = mapped_column(Text)


class EnemyRoundSkills(Base):
    __tablename__ = "enemy_round_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_eternal: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    eff_value1: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value2: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value3: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class EnemySkillCutinExtensions(Base):
    __tablename__ = "enemy_skill_cutin_extensions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    phrase: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    voice_asset_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class EnemySkills(Base):
    __tablename__ = "enemy_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_once: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    eff_value1: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value2: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value3: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    calc_option: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'0'"))


class EquipmentSkillItems(Base):
    __tablename__ = "equipment_skill_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    grade: Mapped[str] = mapped_column(String(255), nullable=False)
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    hp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    attack: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    defense: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    icon_image_id: Mapped[int] = mapped_column(Integer, nullable=False)
    is_eternal: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    equipment_skill_limitation_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class EquipmentSkillLimitations(Base):
    __tablename__ = "equipment_skill_limitations"
    __table_args__ = (
        Index("idx_equipment_skill_limitations_equipment_skill_limitation_set_id", "equipment_skill_limitation_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    equipment_skill_limitation_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class EquipmentSkills(Base):
    __tablename__ = "equipment_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    equipment_skill_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    potential_skill_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    status_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class EventkagiItems(Base):
    __tablename__ = "eventkagi_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    area_category_ids: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class ExchangeableItems(Base):
    __tablename__ = "exchangeable_items"
    __table_args__ = (Index("idx_exchangeable_items_index_exchangeable_items_on_treasure_item_id", "treasure_item_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    treasure_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ExtraSpecialOptions(Base):
    __tablename__ = "extra_special_options"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_special_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'100'"))
    extra_special_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class FinishSkillSets(Base):
    __tablename__ = "finish_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    dialog_order: Mapped[int] = mapped_column(Integer, nullable=False)
    dialog_images: Mapped[dict] = mapped_column(JSON, nullable=False)
    finish_special_id: Mapped[int] = mapped_column(Integer, nullable=False)
    special_view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    costume_special_view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    is_dialog_view_visible: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    effect_description: Mapped[Optional[str]] = mapped_column(Text)
    condition_description: Mapped[Optional[str]] = mapped_column(Text)
    exec_timing_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    exec_limit: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'1'"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class FinishSkills(Base):
    __tablename__ = "finish_skills"
    __table_args__ = (Index("idx_finish_skills_index_finish_skills_on_finish_skill_set_id", "finish_skill_set_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    finish_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    target_type_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    sub_target_type_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    turn: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    calc_option: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    thumb_effect_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    effect_se_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class FinishSpecials(Base):
    __tablename__ = "finish_specials"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    increase_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    aim_target: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ForcedScripts(Base):
    __tablename__ = "forced_scripts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    script_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class GenkaiGimmickSubCategories(Base):
    __tablename__ = "genkai_gimmick_sub_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_type: Mapped[int] = mapped_column(Integer, nullable=False)
    invalid_genkai_gimmick_sub_category_ids: Mapped[dict] = mapped_column(JSON, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class GroupChangeSkillSets(Base):
    __tablename__ = "group_change_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    consume_count: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)


class GroupChangeSymbols(Base):
    __tablename__ = "group_change_symbols"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, server_default=text("''"))
    group_change_skill_set1_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    group_change_skill_set2_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    group_change_skill_set3_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class HeatUpGimmickSkills(Base):
    __tablename__ = "heat_up_gimmick_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    eff_value1: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'0'"))


class HeatUpGimmicks(Base):
    __tablename__ = "heat_up_gimmicks"
    __table_args__ = (
        Index("idx_heat_up_gimmicks_index_heat_up_gimmicks_on_heat_up_gimmick_set_id", "heat_up_gimmick_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    heat_up_gimmick_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    gauge_start: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    heat_up_gimmick_skill_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    override_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class HelpBodies(Base):
    __tablename__ = "help_bodies"
    __table_args__ = (Index("idx_help_bodies_index_help_bodies_on_help_id", "help_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    help_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class HelpCategories(Base):
    __tablename__ = "help_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class Helps(Base):
    __tablename__ = "helps"
    __table_args__ = (Index("idx_helps_index_helps_on_help_category_id", "help_category_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    help_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class ItemCardProperties(Base):
    __tablename__ = "item_card_properties"
    __table_args__ = (Index("idx_item_card_properties_index_item_card_properties_on_card_id", "card_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    exp: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class JukeboxAlbums(Base):
    __tablename__ = "jukebox_albums"
    __table_args__ = (
        Index(
            "idx_jukebox_albums_index_jukebox_albums_on_open_at_and_close_at_and_priority", "open_at", "close_at", "priority"
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    jacket_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    jacket_thumbnail_path: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    close_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class JukeboxTracks(Base):
    __tablename__ = "jukebox_tracks"
    __table_args__ = (
        Index("idx_jukebox_tracks_index_jukebox_tracks_on_jukebox_album_id", "jukebox_album_id"),
        Index(
            "idx_jukebox_tracks_index_jukebox_tracks_on_open_at_and_close_at_and_priority", "open_at", "close_at", "priority"
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    jukebox_album_id: Mapped[int] = mapped_column(Integer, nullable=False)
    bgm_filename: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    close_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class JukeboxUnlockConditions(Base):
    __tablename__ = "jukebox_unlock_conditions"
    __table_args__ = (
        Index("idx_jukebox_unlock_conditions_index_jukebox_unlock_conditions_on_jukebox_track_id", "jukebox_track_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    jukebox_track_id: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class LeaderSkillSets(Base):
    __tablename__ = "leader_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class LeaderSkills(Base):
    __tablename__ = "leader_skills"
    __table_args__ = (
        Index("idx_leader_skills_index_leader_skills_on_leader_skill_set_id", "leader_skill_set_id"),
        Index("idx_leader_skills_index_leader_skills_on_sub_target_type_set_id", "sub_target_type_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    leader_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class LevelBgs(Base):
    __tablename__ = "level_bgs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    bg1_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg1_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg1_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg1_effect_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg1_effect_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg1_effect_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_effect_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_effect_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg2_effect_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_effect_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_effect_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg3_effect_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_effect_enable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_effect_coef: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    bg4_effect_flip_disable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    enable_enemy_effect: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    bg1_effect_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    bg2_effect_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    bg3_effect_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    bg4_effect_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class LinkSkillEfficacies(Base):
    __tablename__ = "link_skill_efficacies"
    __table_args__ = (
        Index("idx_link_skill_efficacies_index_link_skill_efficacies_on_link_skill_lv_id", "link_skill_lv_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    link_skill_lv_id: Mapped[int] = mapped_column(Integer, nullable=False)
    link_check_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lnk_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lnk_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lnk_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value1: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    eff_value2: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    eff_value3: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class LinkSkillLvUpItemConditions(Base):
    __tablename__ = "link_skill_lv_up_item_conditions"
    __table_args__ = (
        Index(
            "idx_link_skill_lv_up_item_conditions_index_link_skill_lv_up_item_conditions_on_item_id",
            "link_skill_lv_up_item_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    link_skill_lv_up_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class LinkSkillLvUpItems(Base):
    __tablename__ = "link_skill_lv_up_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class LinkSkillLvs(Base):
    __tablename__ = "link_skill_lvs"
    __table_args__ = (
        Index("idx_link_skill_lvs_index_link_skill_lvs_on_link_skill_id", "link_skill_id"),
        Index("idx_link_skill_lvs_index_link_skill_lvs_on_skill_lv", "skill_lv"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    skill_lv: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    link_skill_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class LinkSkills(Base):
    __tablename__ = "link_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    need_link_num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    link_skill_lv_up_prob_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    kana: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class Marquees(Base):
    __tablename__ = "marquees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    scene_name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class MetamorphicViews(Base):
    __tablename__ = "metamorphic_views"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    begin_script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    begin_lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    continue_script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    continue_lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    end_script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    end_lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class MissionCategories(Base):
    __tablename__ = "mission_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    dragonball_session_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class MissionCategoryRewards(Base):
    __tablename__ = "mission_category_rewards"
    __table_args__ = (
        Index("idx_mission_category_rewards_index_mission_category_rewards_on_mission_category_id", "mission_category_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mission_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    item1_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item1_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item2_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item2_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item3_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item3_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item4_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item4_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class MissionPeriods(Base):
    __tablename__ = "mission_periods"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mission_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    dot_character_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    wday: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    wday_start_at: Mapped[Optional[datetime.time]] = mapped_column(Time, server_default=text("NULL"))
    wday_hours_to_end: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class MissionRewards(Base):
    __tablename__ = "mission_rewards"
    __table_args__ = (Index("idx_mission_rewards_index_mission_rewards_on_mission_id", "mission_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mission_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    announcement_priority: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    announcement_label: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class Missions(Base):
    __tablename__ = "missions"
    __table_args__ = (
        Index("idx_missions_index_missions_on_area_id", "area_id"),
        Index("idx_missions_index_missions_on_mission_category_id", "mission_category_id"),
        Index("idx_missions_index_missions_on_origin_battle_id", "origin_battle_id"),
        Index("idx_missions_index_missions_on_origin_episode_id", "origin_episode_id"),
        Index("idx_missions_index_missions_on_type_and_start_at_and_end_at", "type", "start_at", "end_at"),
        Index("idx_missions_index_missions_on_z_battle_stage_id", "z_battle_stage_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mission_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    orderer_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    description: Mapped[str] = mapped_column(Text, nullable=False)
    target_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at_hidden: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    panel_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    display_target_value: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    target_100_value: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    link_to: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    area_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    z_battle_stage_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    origin_episode_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    origin_battle_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class OptimalAwakeningGrowths(Base):
    __tablename__ = "optimal_awakening_growths"
    __table_args__ = (
        UniqueConstraint("optimal_awakening_grow_type", "step"),
        Index("idx_optimal_awakening_growths_index_optimal_awakening_growths_on_leader_skill_set_id", "leader_skill_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    optimal_awakening_grow_type: Mapped[int] = mapped_column(Integer, nullable=False)
    step: Mapped[int] = mapped_column(Integer, nullable=False)
    lv_max: Mapped[int] = mapped_column(Integer, nullable=False)
    skill_lv_max: Mapped[int] = mapped_column(Integer, nullable=False)
    passive_skill_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    leader_skill_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class OriginBattleEnemyInformations(Base):
    __tablename__ = "origin_battle_enemy_informations"

    origin_battle_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_info: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class OriginBattlePassiveSkillSetRelations(Base):
    __tablename__ = "origin_battle_passive_skill_set_relations"
    __table_args__ = (
        Index("idx_origin_battle_passive_skill_set_relations_index_on_card_id", "card_id"),
        Index("idx_origin_battle_passive_skill_set_relations_index_on_origin_battle_id", "origin_battle_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_battle_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    passive_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class OriginBattles(Base):
    __tablename__ = "origin_battles"
    __table_args__ = (Index("idx_origin_battles_index_origin_battles_on_origin_spot_id", "origin_spot_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_spot_id: Mapped[int] = mapped_column(Integer, nullable=False)
    bgm_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    background_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    act: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    user_exp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    zeni: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    link_skill_lv_up_prob_rate: Mapped[float] = mapped_column(Float, nullable=False, server_default=text("'0'"))
    enable_battle_auto: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    heat_up_gimmick_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    enemy_info_display_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    first_clear_bonus_stones: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    origin_battle_reward_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    cpu_friend_list_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    unlock_mission_ids: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    limitation_announcement_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class OriginCharacterDialogues(Base):
    __tablename__ = "origin_character_dialogues"
    __table_args__ = (
        Index(
            "idx_origin_character_dialogues_index_origin_character_dialogues_on_round_id_and_timing",
            "origin_battle_round_id",
            "play_timing",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_battle_round_id: Mapped[int] = mapped_column(Integer, nullable=False)
    play_timing: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_card_id: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_type: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_bg_type: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_playback_frame: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_character_asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_phrase_asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    starter_voice_asset_id: Mapped[int] = mapped_column(Integer, nullable=False)
    is_bg_reverse: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_character_asset_lwf: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_shown_on_lost: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    responder_card_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_bg_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_playback_frame: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_character_asset_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_phrase_asset_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    responder_voice_asset_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class OriginEpisodes(Base):
    __tablename__ = "origin_episodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_series_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    banner_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    bgm_id: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class OriginPages(Base):
    __tablename__ = "origin_pages"
    __table_args__ = (UniqueConstraint("origin_episode_id", "page_number"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_episode_id: Mapped[int] = mapped_column(Integer, nullable=False)
    page_number: Mapped[int] = mapped_column(Integer, nullable=False)
    background_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class OriginSeries(Base):
    __tablename__ = "origin_series"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    banner_image_path: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PassiveSkillEffects(Base):
    __tablename__ = "passive_skill_effects"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class PassiveSkillSetRelations(Base):
    __tablename__ = "passive_skill_set_relations"
    __table_args__ = (
        Index(
            "idx_passive_skill_set_relations_index_passive_skill_set_relations_on_passive_skill_set_id",
            "passive_skill_set_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    passive_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    passive_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PassiveSkillSets(Base):
    __tablename__ = "passive_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    itemized_description: Mapped[Optional[str]] = mapped_column(Text)
    sougou_only_itemized_description: Mapped[Optional[str]] = mapped_column(Text)
    kobetu_only_itemized_description: Mapped[Optional[str]] = mapped_column(Text)


class PassiveSkills(Base):
    __tablename__ = "passive_skills"
    __table_args__ = (
        Index("idx_passive_skills_index_passive_skills_on_passive_skill_effect_id", "passive_skill_effect_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exec_game_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_once: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    passive_skill_effect_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class Points(Base):
    __tablename__ = "points"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    amount: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class PotentialBoards(Base):
    __tablename__ = "potential_boards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    comment: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class PotentialEventSelectionTables(Base):
    __tablename__ = "potential_event_selection_tables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    required_stone_for_unrelease: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    comment: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class PotentialEventSelections(Base):
    __tablename__ = "potential_event_selections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    selection_table_id: Mapped[int] = mapped_column(Integer, nullable=False)
    event_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PotentialEvents(Base):
    __tablename__ = "potential_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    additional_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    currency_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class PotentialItems(Base):
    __tablename__ = "potential_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_exclusive: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PotentialSkillLvValues(Base):
    __tablename__ = "potential_skill_lv_values"
    __table_args__ = (UniqueConstraint("potential_skill_id", "lv"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    potential_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    lv: Mapped[int] = mapped_column(Integer, nullable=False)
    value: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PotentialSkills(Base):
    __tablename__ = "potential_skills"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_once: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    variable_column: Mapped[str] = mapped_column(String(255), nullable=False, server_default=text("'eff_value1'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class PotentialSquareConditionSetRelations(Base):
    __tablename__ = "potential_square_condition_set_relations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    condition_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    condition_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class PotentialSquareConditionSets(Base):
    __tablename__ = "potential_square_condition_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    comment: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class PotentialSquareConditions(Base):
    __tablename__ = "potential_square_conditions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    comment: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class PotentialSquareRelations(Base):
    __tablename__ = "potential_square_relations"
    __table_args__ = (
        Index(
            "idx_potential_square_relations_index_potential_square_relations_on_potential_square_id", "potential_square_id"
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    potential_square_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    prev_potential_square_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class PotentialSquares(Base):
    __tablename__ = "potential_squares"
    __table_args__ = (Index("idx_potential_squares_index_potential_squares_on_potential_board_id", "potential_board_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    potential_board_id: Mapped[int] = mapped_column(Integer, nullable=False)
    event_id: Mapped[int] = mapped_column(Integer, nullable=False)
    condition_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    is_locked: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    route: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class QuestCategoryBonusGroups(Base):
    __tablename__ = "quest_category_bonus_groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quest_category_bonus_type: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)


class QuestCategoryBonusRarityTables(Base):
    __tablename__ = "quest_category_bonus_rarity_tables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity_n: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity_r: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity_sr: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity_ssr: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity_ur: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity_lr: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class QuestCategoryBonuses(Base):
    __tablename__ = "quest_category_bonuses"
    __table_args__ = (Index("idx_quest_category_bonuses_index_quest_category_bonuses_on_quest_id", "quest_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quest_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    card_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    quest_category_bonus_rarity_table_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class QuestDropItemViews(Base):
    __tablename__ = "quest_drop_item_views"
    __table_args__ = (Index("idx_quest_drop_item_views_index_quest_drop_item_views_on_quest_id", "quest_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quest_id: Mapped[int] = mapped_column(Integer, nullable=False)
    difficulties: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    item1_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item1_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item2_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item2_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item3_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item3_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item4_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item4_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item5_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item5_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item6_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    item6_type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class Quests(Base):
    __tablename__ = "quests"
    __table_args__ = (
        UniqueConstraint("area_id", "prev_quest_id"),
        Index("idx_quests_index_quests_on_area_id", "area_id"),
        Index("idx_quests_index_quests_on_prev_quest_id", "prev_quest_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    area_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    can_ignore_difficulty_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    boostable: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    enable_sugoroku_auto: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    enable_battle_auto: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    enemy_info_display_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    prev_quest_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    any_clear_bonus_stones: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    all_clear_bonus_stones: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    visit_count_max: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    interval_reset_visited_days: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    limitation_announcement_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class RankRanges(Base):
    __tablename__ = "rank_ranges"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    min: Mapped[int] = mapped_column(Integer, nullable=False)
    max: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class RankStatuses(Base):
    __tablename__ = "rank_statuses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rank: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    exp_total: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    act_max: Mapped[int] = mapped_column(Integer, nullable=False)
    friends_capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RelatedCardCategories(Base):
    __tablename__ = "related_card_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RelatedLinkSkills(Base):
    __tablename__ = "related_link_skills"
    __table_args__ = (UniqueConstraint("enemy_skill_id", "link_skill_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    link_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RelatedOptimalAwakenings(Base):
    __tablename__ = "related_optimal_awakenings"
    __table_args__ = (UniqueConstraint("enemy_skill_id", "card_category_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    card_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RelatedPassiveSkillSets(Base):
    __tablename__ = "related_passive_skill_sets"
    __table_args__ = (UniqueConstraint("enemy_skill_id", "passive_skill_set_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    passive_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RevivalViews(Base):
    __tablename__ = "revival_views"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    effect_pack_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    script_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    script_lite_flicker_rate: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class RmbattleHelpBodies(Base):
    __tablename__ = "rmbattle_help_bodies"
    __table_args__ = (Index("idx_rmbattle_help_bodies_index_rmbattle_help_bodies_on_rmbattle_help_id", "rmbattle_help_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rmbattle_help_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class RmbattleHelpCategories(Base):
    __tablename__ = "rmbattle_help_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class RmbattleHelps(Base):
    __tablename__ = "rmbattle_helps"
    __table_args__ = (
        Index("idx_rmbattle_helps_index_rmbattle_helps_on_rmbattle_help_category_id", "rmbattle_help_category_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rmbattle_help_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class RmbattleMissionRewards(Base):
    __tablename__ = "rmbattle_mission_rewards"
    __table_args__ = (
        Index("idx_rmbattle_mission_rewards_index_rmbattle_mission_rewards_on_rmbattle_mission_id", "rmbattle_mission_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rmbattle_mission_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    gift_description: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class RmbattleMissions(Base):
    __tablename__ = "rmbattle_missions"
    __table_args__ = (Index("idx_rmbattle_missions_index_rmbattle_missions_on_rmbattle_id_and_type", "rmbattle_id", "type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rmbattle_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    target_value: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ScoreBenefits(Base):
    __tablename__ = "score_benefits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SdArenas(Base):
    __tablename__ = "sd_arenas"
    __table_args__ = (Index("idx_sd_arenas_index_sd_arenas_on_sd_map_id", "sd_map_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sd_map_id: Mapped[int] = mapped_column(Integer, nullable=False)
    position_x: Mapped[int] = mapped_column(Integer, nullable=False)
    position_y: Mapped[int] = mapped_column(Integer, nullable=False)
    symbol_item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    symbol_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    background_image_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SdCharacters(Base):
    __tablename__ = "sd_characters"
    __table_args__ = (UniqueConstraint("series", "number"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    card_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    attack: Mapped[int] = mapped_column(Integer, nullable=False)
    hp: Mapped[int] = mapped_column(Integer, nullable=False)
    element: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False)
    series: Mapped[int] = mapped_column(Integer, nullable=False)
    number: Mapped[int] = mapped_column(Integer, nullable=False)
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)


class SdHelpBodies(Base):
    __tablename__ = "sd_help_bodies"
    __table_args__ = (Index("idx_sd_help_bodies_index_sd_help_bodies_on_sd_help_id", "sd_help_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sd_help_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class SdHelpCategories(Base):
    __tablename__ = "sd_help_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class SdHelps(Base):
    __tablename__ = "sd_helps"
    __table_args__ = (Index("idx_sd_helps_index_sd_helps_on_sd_help_category_id", "sd_help_category_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sd_help_category_id: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    num: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class SdMaps(Base):
    __tablename__ = "sd_maps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    background_image_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SdPacks(Base):
    __tablename__ = "sd_packs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SdStages(Base):
    __tablename__ = "sd_stages"
    __table_args__ = (Index("idx_sd_stages_index_sd_stages_on_sd_arena_id", "sd_arena_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sd_arena_id: Mapped[int] = mapped_column(Integer, nullable=False)
    sd_enemy_table_id: Mapped[int] = mapped_column(Integer, nullable=False)
    respawn_minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    position_x: Mapped[int] = mapped_column(Integer, nullable=False)
    position_y: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class Shops(Base):
    __tablename__ = "shops"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    close_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    item_change_interval_sec: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    required_stone_to_change_item: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class SkillCausalities(Base):
    __tablename__ = "skill_causalities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    causality_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    cau_val1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    cau_val2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    cau_val3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SkillGroupRelations(Base):
    __tablename__ = "skill_group_relations"
    __table_args__ = (UniqueConstraint("target_type", "target_id", "skill_group_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    target_type: Mapped[str] = mapped_column(String(255), nullable=False)
    target_id: Mapped[int] = mapped_column(Integer, nullable=False)
    skill_group_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SkillGroups(Base):
    __tablename__ = "skill_groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SkillLabels(Base):
    __tablename__ = "skill_labels"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_display: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SoundEffectOffsets(Base):
    __tablename__ = "sound_effect_offsets"
    __table_args__ = (
        Index("idx_sound_effect_offsets_index_sound_effect_offsets_on_sound_effect_set_id", "sound_effect_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sound_effect_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    sound_effect_id: Mapped[int] = mapped_column(Integer, nullable=False)
    start_offset_millisecond: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SpecialBonuses(Base):
    __tablename__ = "special_bonuses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    efficacy_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    target_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    calc_option: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    turn: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    probability: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    eff_value1: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value2: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eff_value3: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class SpecialCategories(Base):
    __tablename__ = "special_categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    raw_attribute: Mapped[int] = mapped_column(Integer, nullable=False, unique=True, server_default=text("'0'"))
    name: Mapped[str] = mapped_column(String(255), nullable=False, server_default=text("''"))
    display_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SpecialItems(Base):
    __tablename__ = "special_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)


class SpecialSets(Base):
    __tablename__ = "special_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    aim_target: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    increase_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lv_bonus: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_inactive: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    causality_description: Mapped[Optional[str]] = mapped_column(Text)


class SpecialViews(Base):
    __tablename__ = "special_views"
    __table_args__ = (Index("idx_special_views_index_special_views_on_special_category_id", "special_category_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    cut_in_card_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_name_no: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_motion: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    energy_color: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    special_category_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class Specials(Base):
    __tablename__ = "specials"
    __table_args__ = (Index("idx_specials_index_specials_on_special_set_id_and_type", "special_set_id", "type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    special_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    prob: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class StandbySkillSetFinishSkillSetRelations(Base):
    __tablename__ = "standby_skill_set_finish_skill_set_relations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    standby_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    finish_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class StandbySkillSets(Base):
    __tablename__ = "standby_skill_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    ingame_icon_path: Mapped[str] = mapped_column(String(255), nullable=False)
    special_view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    costume_special_view_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    effect_description: Mapped[Optional[str]] = mapped_column(Text)
    condition_description: Mapped[Optional[str]] = mapped_column(Text)
    exec_limit: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("'1'"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class StandbySkills(Base):
    __tablename__ = "standby_skills"
    __table_args__ = (Index("idx_standby_skills_index_standby_skills_on_standby_skill_set_id", "standby_skill_set_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    standby_skill_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    target_type_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    sub_target_type_set_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    turn: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_type: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    calc_option: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    thumb_effect_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    effect_se_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class StatusExtensions(Base):
    __tablename__ = "status_extensions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    amount: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class SubTargetTypeSets(Base):
    __tablename__ = "sub_target_type_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SubTargetTypes(Base):
    __tablename__ = "sub_target_types"
    __table_args__ = (
        Index("idx_sub_target_types_index_sub_target_types_on_sub_target_type_set_id", "sub_target_type_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    target_value_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SugorokuMapBossDropItems(Base):
    __tablename__ = "sugoroku_map_boss_drop_items"
    __table_args__ = (
        Index("idx_sugoroku_map_boss_drop_items_index_sugoroku_map_boss_drop_items_on_quest_id", "quest_id"),
        Index("idx_sugoroku_map_boss_drop_items_index_sugoroku_map_boss_drop_items_on_sugoroku_map_id", "sugoroku_map_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sugoroku_map_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quest_id: Mapped[int] = mapped_column(Integer, nullable=False)
    drop_type: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SugorokuMapEnemyInformations(Base):
    __tablename__ = "sugoroku_map_enemy_informations"

    sugoroku_map_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_info: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SugorokuMapPuzzleColors(Base):
    __tablename__ = "sugoroku_map_puzzle_colors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    weight_blue: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight_green: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight_purple: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight_red: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight_yellow: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    weight_rainbow: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SugorokuMaps(Base):
    __tablename__ = "sugoroku_maps"
    __table_args__ = (UniqueConstraint("quest_id", "difficulty"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    difficulty: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sugoroku_bgm_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    battle_bgm_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    boss_bgm_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    battle_background_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    act: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eventkagi_num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    user_exp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    zeni: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_script_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    finish_script_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sugoroku_map_puzzle_color_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    is_cpu_only: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    quest_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    first_focus_step: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    dice_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    link_skill_lv_up_prob_rate: Mapped[Optional[float]] = mapped_column(Float, server_default=text("NULL"))
    sugoroku_map_reward_group_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    cpu_friend_list_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class SupportFilms(Base):
    __tablename__ = "support_films"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SupportItems(Base):
    __tablename__ = "support_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff1_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff1_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff1_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff2_value1: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff2_value2: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    eff2_value3: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    ingame_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    max_per_quest: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    max_per_quest_extended: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    efficacy_values1: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    efficacy_values2: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class SupportMemories(Base):
    __tablename__ = "support_memories"
    __table_args__ = (
        Index(
            "idx_support_memories_index_support_memories_on_open_at_and_close_at_and_priority",
            "open_at",
            "close_at",
            "priority",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    max_exec_count: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    support_film_id: Mapped[int] = mapped_column(Integer, nullable=False)
    cost: Mapped[int] = mapped_column(Integer, nullable=False)
    unlock_quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    open_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    close_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SupportMemoryEnhancementItems(Base):
    __tablename__ = "support_memory_enhancement_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SupportMemoryEnhancementLevels(Base):
    __tablename__ = "support_memory_enhancement_levels"
    __table_args__ = (
        Index(
            "idx_support_memory_enhancement_levels_index_support_memory_enhancement_levels_on_enhanced_id",
            "enhanced_support_memory_id",
        ),
        Index(
            "idx_support_memory_enhancement_levels_index_support_memory_enhancement_levels_on_support_memory_id",
            "support_memory_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    root_support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False)
    support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    enhanced_support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SupportMemoryEnhancementRequireItems(Base):
    __tablename__ = "support_memory_enhancement_require_items"
    __table_args__ = (
        Index(
            "idx_support_memory_enhancement_require_items_index_support_memory_enhancement_require_items",
            "support_memory_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    support_memory_enhancement_item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class SupportMemorySkills(Base):
    __tablename__ = "support_memory_skills"
    __table_args__ = (
        Index("idx_support_memory_skills_index_support_memory_skills_on_support_memory_id", "support_memory_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    support_memory_id: Mapped[int] = mapped_column(Integer, nullable=False)
    exec_timing_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    target_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    sub_target_type_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    probability: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'100'"))
    turn: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    calc_option: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    efficacy_values: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(Text)
    target_type_values: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
    causality_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class Tips(Base):
    __tablename__ = "tips"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    weight: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, nullable=False, server_default=text("'2000-01-01 00:00:00'")
    )
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text("'2030-01-01 00:00:00'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    image_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class TitleScreens(Base):
    __tablename__ = "title_screens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    bg_anime: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    chara_anime: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    bgm_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class TrainingFields(Base):
    __tablename__ = "training_fields"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    level_bg_id: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    zeni: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    elements: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    multiplier: Mapped[Optional[float]] = mapped_column(Float, server_default=text("NULL"))
    addend: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    card_training_field_exp_up_prob_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class TrainingItems(Base):
    __tablename__ = "training_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    element: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    exp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    zeni_to_use: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class TransformationDescriptions(Base):
    __tablename__ = "transformation_descriptions"
    __table_args__ = (UniqueConstraint("skill_type", "skill_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    skill_type: Mapped[str] = mapped_column(String(255), nullable=False, server_default=text("''"))
    skill_id: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class TransformationTypeNames(Base):
    __tablename__ = "transformation_type_names"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    battle_param_value: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class TransformationViews(Base):
    __tablename__ = "transformation_views"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    begin_script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    begin_lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    end_script_name: Mapped[str] = mapped_column(String(255), nullable=False)
    end_lite_flicker_rate: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class TreasureItems(Base):
    __tablename__ = "treasure_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(400), nullable=False)
    rarity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    selling_exchange_point: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    image_suffix_number: Mapped[int] = mapped_column(Integer, nullable=False)
    will_expire: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class TutorialPhases(Base):
    __tablename__ = "tutorial_phases"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tutorial_scene_url: Mapped[str] = mapped_column(String(255), nullable=False)
    number: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    parameters: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class TutorialProcesses(Base):
    __tablename__ = "tutorial_processes"
    __table_args__ = (Index("idx_tutorial_processes_index_tutorial_processes_on_step_id", "step_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    step_id: Mapped[int] = mapped_column(Integer, nullable=False)
    process_type: Mapped[str] = mapped_column(String(255), nullable=False)
    number: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    parameters: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))


class TutorialSteps(Base):
    __tablename__ = "tutorial_steps"
    __table_args__ = (Index("idx_tutorial_steps_index_tutorial_steps_on_phase_id", "phase_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    phase_id: Mapped[int] = mapped_column(Integer, nullable=False)
    number: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    is_resume_point: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class UltimateSpecials(Base):
    __tablename__ = "ultimate_specials"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    increase_rate: Mapped[int] = mapped_column(Integer, nullable=False)
    aim_target: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class UnusedAssetPaths(Base):
    __tablename__ = "unused_asset_paths"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class WallpaperItems(Base):
    __tablename__ = "wallpaper_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    description: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class WallpaperSchedules(Base):
    __tablename__ = "wallpaper_schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    wallpaper_item_id: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    update_end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleCheckPoints(Base):
    __tablename__ = "z_battle_check_points"
    __table_args__ = (
        UniqueConstraint("z_battle_stage_id", "level"),
        Index("idx_z_battle_check_points_index_z_battle_check_points_on_z_battle_stage_id", "z_battle_stage_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_stage_id: Mapped[int] = mapped_column(Integer, nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False)
    act: Mapped[int] = mapped_column(Integer, nullable=False)
    eventkagi_num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    z_battle_normal_reward_table_group_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    main_reward_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ZBattleEnemies(Base):
    __tablename__ = "z_battle_enemies"
    __table_args__ = (Index("idx_z_battle_enemies_index_z_battle_enemies_on_z_battle_stage_id", "z_battle_stage_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ordinal_num: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_level: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    base_hp: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    base_attack: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    base_defence: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    hp_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    attack_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    defence_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    special_attack_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    performance_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    skill_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    z_battle_stage_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    end_level: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ZBattleEnemyCardEscalations(Base):
    __tablename__ = "z_battle_enemy_card_escalations"
    __table_args__ = (Index("idx_z_battle_enemy_card_escalations_card_by_escalation_type", "escalation_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    level: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_id: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleEnemySkillEscalations(Base):
    __tablename__ = "z_battle_enemy_skill_escalations"
    __table_args__ = (Index("idx_z_battle_enemy_skill_escalations_skill_by_escalation_type", "escalation_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    level: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    enemy_skill_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ZBattleEnemyStatusEscalations(Base):
    __tablename__ = "z_battle_enemy_status_escalations"
    __table_args__ = (Index("idx_z_battle_enemy_status_escalations_strength_by_escalation_type", "escalation_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    level: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    escalation_value: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleFirstRewardLevelRanges(Base):
    __tablename__ = "z_battle_first_reward_level_ranges"
    __table_args__ = (UniqueConstraint("z_battle_stage_id", "level"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_stage_id: Mapped[int] = mapped_column(Integer, nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False)
    z_battle_first_reward_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    main_reward_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ZBattleFirstRewards(Base):
    __tablename__ = "z_battle_first_rewards"
    __table_args__ = (
        Index("idx_z_battle_first_rewards_index_z_battle_first_rewards_set_id", "z_battle_first_reward_set_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_first_reward_set_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleNormalRewardTables(Base):
    __tablename__ = "z_battle_normal_reward_tables"
    __table_args__ = (
        Index(
            "idx_z_battle_normal_reward_tables_index_z_battle_normal_reward_tables_table_group_id",
            "z_battle_normal_reward_table_group_id",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_normal_reward_table_group_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleNormalRewards(Base):
    __tablename__ = "z_battle_normal_rewards"
    __table_args__ = (
        Index("idx_z_battle_normal_rewards_index_z_battle_normal_rewards_table_id", "z_battle_normal_reward_table_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_normal_reward_table_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    item_type: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    card_exp_init: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattlePowerupThresholds(Base):
    __tablename__ = "z_battle_powerup_thresholds"
    __table_args__ = (
        Index("idx_z_battle_powerup_thresholds_index_z_battle_powerup_thresholds_on_z_battle_stage_id", "z_battle_stage_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_stage_id: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    hp: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    atk: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    def_: Mapped[Optional[int]] = mapped_column("def", Integer, server_default=text("NULL"))
    special_atk: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))


class ZBattlePowerupViews(Base):
    __tablename__ = "z_battle_powerup_views"
    __table_args__ = (
        Index(
            "idx_z_battle_powerup_views_index_z_battle_powerup_views_on_enemy_skill_efficacy_type",
            "enemy_skill_efficacy_type",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    enemy_skill_efficacy_type: Mapped[int] = mapped_column(Integer, nullable=False)
    texture_name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleStageLevelupViews(Base):
    __tablename__ = "z_battle_stage_levelup_views"
    __table_args__ = (
        Index("idx_z_battle_stage_levelup_views_index_z_battle_stage_levelup_views_on_stage_level", "stage_level"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stage_level: Mapped[int] = mapped_column(Integer, nullable=False)
    scene_name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    to_super_stage_scene_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    to_normal_stage_scene_name: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))


class ZBattleStageViews(Base):
    __tablename__ = "z_battle_stage_views"
    __table_args__ = (
        Index("idx_z_battle_stage_views_index_z_battle_stage_views_on_z_battle_stage_id", "z_battle_stage_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    z_battle_stage_id: Mapped[int] = mapped_column(Integer, nullable=False)
    enemy_name: Mapped[str] = mapped_column(String(255), nullable=False)
    enemy_nickname: Mapped[str] = mapped_column(String(255), nullable=False)
    enemy_resource_id: Mapped[int] = mapped_column(Integer, nullable=False)
    params: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)


class ZBattleStages(Base):
    __tablename__ = "z_battle_stages"
    __table_args__ = (
        Index(
            "idx_z_battle_stages_idx_on_eventkagi_end_at_eventkagi_start_at_e0a39fd942",
            "eventkagi_end_at",
            "eventkagi_start_at",
        ),
        Index("idx_z_battle_stages_index_z_battle_stages_on_end_at_and_start_at", "end_at", "start_at"),
        Index("idx_z_battle_stages_index_z_battle_stages_on_related_z_battle_stage_id", "related_z_battle_stage_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    type: Mapped[str] = mapped_column(String(255), nullable=False)
    z_battle_stage_effect_escalation_type: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'0'"))
    start_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    end_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    enable_battle_auto: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("'1'"))
    banner_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    listbutton_image_path: Mapped[Optional[str]] = mapped_column(String(255), server_default=text("NULL"))
    announcement_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    eventkagi_start_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, server_default=text("NULL"))
    eventkagi_end_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, server_default=text("NULL"))
    cpu_friend_list_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    related_z_battle_stage_id: Mapped[Optional[int]] = mapped_column(Integer, server_default=text("NULL"))
    unlock_conditions: Mapped[Optional[dict]] = mapped_column(JSON, server_default=text("NULL"))
