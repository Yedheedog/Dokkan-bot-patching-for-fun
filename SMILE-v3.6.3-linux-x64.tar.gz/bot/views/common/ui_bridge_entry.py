#!/usr/bin/env python3
"""
GUI Bridge Entry Point (Child Process)

This script runs in a separate process to launch PySide6 dialogs.
It reads a JSON task specification from stdin and writes the result to stdout.

Communication Protocol:
  Input (stdin):  {"task": "select_cards", "params": {...}}
  Output (stdout): {"ok": true, "result": ...} or {"ok": false, "error": "..."}

This ensures the parent process (CLI) never creates a QApplication,
preventing Qt event loop conflicts with terminal input() on macOS/Linux.
"""

import json
import sys
from pathlib import Path


src_dir = Path(__file__).parent.parent.parent
if str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))


def main():
    """Main entry point for the GUI bridge child process."""
    try:
        # Check if input file is provided as argument
        if len(sys.argv) > 1 and sys.argv[1] == "--input-file":
            if len(sys.argv) < 3:
                _write_error("--input-file requires a file path")
                return 1

            # Read from file
            input_file = Path(sys.argv[2])
            if not input_file.exists():
                _write_error(f"Input file not found: {input_file}")
                return 1

            with open(input_file, "r", encoding="utf-8") as f:
                payload = json.load(f)
        else:
            # Read task specification from stdin (original behavior)
            payload = json.load(sys.stdin)

        task = payload.get("task")
        params = payload.get("params", {})

        if not task:
            _write_error("No task specified")
            return 1

        result = _dispatch_task(task, params)

        _write_success(result)
        return 0

    except json.JSONDecodeError as e:
        _write_error(f"Invalid JSON input: {e}")
        return 1
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        _write_error(f"Unexpected error: {e}\n\nTraceback:\n{error_details}")
        return 1


def _dispatch_task(task: str, params: dict):
    """Dispatch the task to the appropriate GUI component."""

    if task == "select_cards":
        from database.db_connector import get_database_session
        from database.db_handler import DBHandler
        from views.box.gallery import DokkanCardViewer

        session = get_database_session()
        db_handler = DBHandler(session)

        return DokkanCardViewer.launch(
            cards=params.get("cards"),
            skip_sr=params.get("skip_sr", True),
            is_view_only=params.get("is_view_only", False),
            select_limit=params.get("select_limit"),
            chain_farming_mode=params.get("chain_farming_mode", False),
            chain_farming_stage_id=params.get("chain_farming_stage_id"),
            chain_farming_difficulty=params.get("chain_farming_difficulty"),
            db_handler=db_handler,
            region=params.get("region", "jp"),
        )

    elif task == "select_medals":
        from views.medal.medal import MedalsSelector

        return MedalsSelector.launch(
            medals_data=params.get("medals_data"),
            read_only_mode=params.get("read_only_mode"),
            initial_selection_map=params.get("initial_selection_map"),
        )

    elif task == "select_events":
        from views.event.event import EventItemSelector

        return EventItemSelector.launch(
            data=params.get("data"),
            pre_selected_items=params.get("pre_selected_items"),
            select_limit=params.get("select_limit"),
        )

    elif task == "select_banner":
        from views.summon.banner import BannerSelector

        return BannerSelector.launch(banners_data_list=params.get("banners_data_list"))

    elif task == "show_summon_results":
        from views.summon.summon import CardViewer

        CardViewer.launch(
            card_ids=params.get("card_ids"),
            limited_cards=params.get("limited_cards"),
            lr_seed_cards=params.get("lr_seed_cards"),
            carnival_only_cards=params.get("carnival_only_cards"),
        )
        return None

    elif task == "launch_config":
        from ui.config_interface import SimpleConfigInterface

        SimpleConfigInterface.launch(config_manager=params.get("config_manager"))
        return None

    elif task == "select_teams":
        from views.team_selector import TeamSelectorUI

        return TeamSelectorUI.launch(
            teams_data=params.get("teams_data"),
            cards_data=params.get("cards_data"),
        )

    elif task == "card_farming_dialog":
        from bot.managers.event_manager import EventManager
        from database.db_connector import get_database_session
        from database.db_handler import DBHandler
        from views.farming.card_farming_dialog import CardFarmingDialog

        session = get_database_session()
        db_handler = DBHandler(session)

        event_manager = EventManager(db_handler)
        raw_event_data = params.get("raw_event_data")
        if raw_event_data:
            event_manager.load_and_process_event_data(raw_event_data)

        return CardFarmingDialog.launch(
            farmable_cards=params.get("farmable_cards"),
            user_owned_cards=params.get("user_owned_cards"),
            db_handler=db_handler,
            event_manager=event_manager,
        )

    elif task == "sa_farming_dialog":
        from bot.managers.event_manager import EventManager
        from database.db_connector import get_database_session
        from database.db_handler import DBHandler
        from views.farming.sa_farming_dialog import SAFarmingDialog

        session = get_database_session()
        db_handler = DBHandler(session)

        event_manager = EventManager(db_handler)
        raw_event_data = params.get("raw_event_data")
        if raw_event_data:
            event_manager.load_and_process_event_data(raw_event_data)

        return SAFarmingDialog.launch(
            cards_data=params.get("cards_data"),
            raw_event_data=raw_event_data,
            db_handler=db_handler,
            event_manager=event_manager,
        )

    else:
        raise ValueError(f"Unknown task: {task}")


def _write_success(result):
    """Write a success response to stdout."""
    response = {"ok": True, "result": result}
    print(json.dumps(response), flush=True)


def _write_error(error_msg: str):
    """Write an error response to stdout."""
    response = {"ok": False, "error": error_msg}
    print(json.dumps(response), flush=True)


if __name__ == "__main__":
    sys.exit(main())
