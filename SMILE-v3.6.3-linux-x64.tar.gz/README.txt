=================================================================
                  SMILE DOKKAN BOT - v3.6.3
=================================================================

PREREQUISITES
-------------
Python 3.12 REQUIRED - recommended version 3.12.10 (NOT 3.11, 3.13, or 3.14!)

Why Python 3.12 specifically?
• The bot is compiled for this exact version (CPython 3.12)
• Other versions will NOT work due to binary incompatibility
• Check your version: python --version (must show 3.12.x)

Where to download:
• Python 3.12.10 (direct): https://www.python.org/downloads/release/python-31210/
• Choose the 64-bit installer for your operating system
• IMPORTANT: During installation, check "Add Python to PATH"

=================================================================

QUICK START
-----------
1. Windows: Double-click launch_bot.bat
   Mac/Linux: Open Terminal, navigate to bot folder, run:
     chmod +x launch_bot.sh
     ./launch_bot.sh
2. First launch creates virtual environment automatically (~1-2 minutes)
3. SELECT OPTION 0 FOR INTERACTIVE ONBOARDING
4. Choose your language (English/Français)
5. Follow step-by-step guide through all features

=================================================================

WHAT DOES THIS BOT DO?
-----------------------
SMILE is a comprehensive automation bot for Dragon Ball Z Dokkan Battle.

Features:
• Farm dragon stones from story, events, and missions
• Automate link leveling for your characters
• Auto-complete missions and Ultimate Clash
• Farm awakening medals and cards
• Manage teams, summons, and character box
• And much more!

FREE version covers 99% of the game content:
• Complete story farming (~8,000 dragon stones)
• Manual team building for all stages
• Basic automation for events and Z-Battles
• Character box management and summoning
• Gift claiming and stamina management
• Everything achievable with free tier (requires patience & strategy)

Premium tiers offer Quality of Life improvements:
• PREMIUM ($2.99/month): Auto team building, link farming, awakening
• PREMIUM+ ($5.00/month): AI team building, shop, advanced features

=================================================================

ANTIVIRUS FALSE POSITIVES
--------------------------
Your antivirus may flag .pyd files as suspicious.

This is a FALSE POSITIVE from Python compilation.
• The bot contains NO malware
• .pyd files are compiled Python modules (like .dll on Windows)
• Common files flagged: payload_generator.pyd, anti_debug.pyd

Solution:
1. Add bot folder to antivirus exceptions/exclusions
2. Windows Defender: Settings > Virus & threat protection > Exclusions
3. Other antivirus: Check their documentation for "add exception"

=================================================================

COMMON MISTAKES TO AVOID
-------------------------
❌ Using Python 3.11, 3.13, or 3.14
   ✓ Use Python 3.12 (recommended 3.12.10)

❌ Running from cloud folders (OneDrive, Google Drive, Dropbox)
   ✓ Extract to a local folder (C:\, D:\, Documents, etc.)

❌ Wrong platform setting before Google login
   ✓ Always confirm platform in the dialog that appears

❌ Expecting bot to run without Python installed
   ✓ Python 3.12 (recommended 3.12.10) is REQUIRED - bot cannot run without it

❌ Not reading error messages or logs
   ✓ Check console output and logs/ folder for errors

=================================================================

GETTING HELP
------------
Interactive Onboarding:
• Press 0 in main menu for step-by-step tutorials
• Available in English and French
• Covers all menu options and commands

Complete Documentation:
• Open guide_faq.html in your browser (option 6 from main menu)
• Comprehensive command reference with examples
• Configuration guide and troubleshooting

Discord Support:
• Join our community: discord.gg/dbz-dokkanbattle
• Free users: Use general help channels
• Premium users: Open support tickets for priority assistance

Logs for Troubleshooting:
• Location: bot/logs/
• Format: log_YYYY-MM-DD.log
• Contains: API requests, errors, debug information
• Include relevant logs when asking for help

=================================================================

FIRST STEPS
-----------
After launching the bot:

For New Users:
1. Press 0 for interactive onboarding
2. Choose your language
3. Follow the step-by-step guide
4. Create account (option 1) or login (options 2-4)


=================================================================

TROUBLESHOOTING
---------------
Bot won't start:
• Check Python version: python --version (must be 3.12.x; recommended 3.12.10)
• Add bot folder to antivirus exceptions
• Ensure folder is NOT in cloud storage (OneDrive, Google Drive) or a temp/zip folder
• Do NOT run as administrator - it usually causes more problems than it fixes;
  instead move the bot to a local folder you own (e.g. C:\DokkanBot)
• Delete env/ folder and restart if dependencies fail

Python modules not installing:
1. Delete env/ folder from bot directory
2. Upgrade pip: python -m pip install --upgrade pip
3. Clear cache: python -m pip cache purge
4. Restart computer
5. Relaunch bot

Commands not working:
• Verify you're logged in successfully
• Try the 'refresh' command to re-authenticate
• Check command syntax with 'help'
• Ensure you have required tier permissions
• Check logs/ folder for error details

=================================================================

SUPPORT & COMMUNITY
-------------------
Discord: discord.gg/dbz-dokkanbattle
Developer: Available in Discord server
Updates: Announced in Discord #announcements channel

When asking for help, always include:
1. What you were trying to do
2. What you expected to happen
3. What actually happened
4. Screenshots of errors
5. Relevant log lines (last 10-20 lines before error)

FREE users: General help channels
PREMIUM users: Support tickets for priority assistance

=================================================================
