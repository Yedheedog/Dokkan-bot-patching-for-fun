@echo off
REM ========================================
REM Dokkan Battle Bot - Windows Launcher
REM ========================================

setlocal enabledelayedexpansion

REM ------------------------------------------------------------
REM Anchor to THIS script's own folder. Running the file as
REM Administrator - or double-clicking it from another window -
REM starts cmd.exe in C:\Windows\System32, which breaks every
REM relative path below and causes "file not found". cd /d back
REM to wherever launch_bot.bat actually lives.
cd /d "%~dp0"

title Dokkan Battle Bot - Windows Launcher

echo.
echo ========================================
echo    DOKKAN BATTLE BOT - WINDOWS LAUNCHER
echo ========================================
echo.

REM ------------------------------------------------------------
REM [1/7] Environment sanity checks. These only WARN - they never
REM stop the bot, except when the bot files are genuinely missing.
echo [1/7] Checking your environment...
echo     Folder: "%CD%"

REM --- Running straight from inside the .zip / a temp folder? ---
set "IS_TEMP="
echo "%CD%" | find /I "\Temp\" >nul && set "IS_TEMP=1"
echo "%CD%" | find /I "\Temporary Internet" >nul && set "IS_TEMP=1"
if defined IS_TEMP (
    echo.
    echo     WARNING: This looks like a temporary folder.
    echo     If you launched the bot straight from inside the .zip, Windows
    echo     only copied a few files to a temp folder and it WILL fail.
    echo     Fix: right-click the .zip, choose Extract All, then run
    echo     launch_bot.bat from the extracted folder.
    echo.
)

REM --- Folder living inside OneDrive? ---
set "IS_ONEDRIVE="
echo "%CD%" | find /I "OneDrive" >nul && set "IS_ONEDRIVE=1"
if defined IS_ONEDRIVE (
    echo.
    echo     WARNING: This folder is inside OneDrive.
    echo     OneDrive can sync or lock files while the bot runs and cause
    echo     read/write errors. If you hit problems, move the whole bot
    echo     folder somewhere simple like C:\DokkanBot and run it from there.
    echo.
)

REM --- Running as Administrator? Usually unnecessary. ---
set "IS_ADMIN="
net session >nul 2>&1 && set "IS_ADMIN=1"
if defined IS_ADMIN (
    echo.
    echo     NOTE: You are running as Administrator. This is normally NOT
    echo     needed. If the bot cannot create files or find its modules,
    echo     close this window and just double-click launch_bot.bat.
    echo.
)

REM --- Are the bot files actually next to this script? ---
if not exist "requirements.txt" if not exist "bot\bot_launcher.py" if not exist "bot_launcher.py" (
    echo.
    echo ERROR: The bot files were not found next to this launcher.
    echo     Current folder: "%CD%"
    echo     This almost always means the .zip was not extracted, or this
    echo     .bat was copied somewhere on its own.
    echo     Fix: extract the FULL .zip, then run launch_bot.bat from inside
    echo     the extracted folder.
    echo.
    pause
    exit /b 1
)
echo [OK] Environment check done

REM ------------------------------------------------------------
REM [2/7] Locate a usable Python 3.12 interpreter
echo.
echo [2/7] Checking Python installation...
echo     The bot needs Python 3.12 - recommended version 3.12.10.
echo     Python 3.11, 3.13 and 3.14 will NOT work: the compiled files
echo     are built for 3.12 only.

set "PYTHON_CMD="
set "PY_ARGS="
set "PYTHON_VERSION="

REM Try the official Python launcher
py -3.12 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=py"
    set "PY_ARGS=-3.12"
    goto :found_python
)

REM Scan the py launcher's installed list for any 3.12
for /f "tokens=2 delims= " %%v in ('py -0p 2^>nul ^| findstr /r "3\.12"') do (
    if exist "%%v" (
        set "PYTHON_CMD=%%v"
        set "PY_ARGS="
        goto :found_python
    )
)

REM Check common install directories, including the per-user location
for %%p in (
    "C:\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
    "C:\Program Files (x86)\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
) do (
    if exist %%~p (
        set "PYTHON_CMD=%%~p"
        set "PY_ARGS="
        goto :found_python
    )
)

REM Last resort: a "python" on PATH that reports 3.12
for /f "tokens=2" %%v in ('python --version 2^>^&1') do (
    echo %%v | find "3.12" >nul
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
        set "PY_ARGS="
        goto :found_python
    )
)

REM No valid Python 3.12 found - show what IS installed to help the user
echo.
echo ERROR: Python 3.12 was not found on this PC.
echo.
echo     The bot ONLY works on Python 3.12 - recommended 3.12.10.
echo     Other versions you may have, like 3.11, 3.13 or 3.14, will not work.
echo.
echo     Download Python 3.12.10 here:
echo         https://www.python.org/downloads/release/python-31210/
echo     During setup, TICK the box "Add python.exe to PATH", then run
echo     this launcher again.
echo.
echo     For reference, Python versions detected on this PC right now:
py -0 2>nul
python --version 2>nul
echo.
pause
exit /b 1

:found_python
for /f "tokens=2" %%i in ('%PYTHON_CMD% %PY_ARGS% --version 2^>^&1') do set "PYTHON_VERSION=%%i"
echo [OK] Found Python %PYTHON_VERSION% using "%PYTHON_CMD% %PY_ARGS%"

REM ------------------------------------------------------------
REM [3/7] Virtual environment
echo.
echo [3/7] Checking virtual environment...
if not exist "env" (
    echo Creating virtual environment...
    %PYTHON_CMD% %PY_ARGS% -m venv "env"
    if %errorlevel% neq 0 (
        echo.
        echo ERROR: Failed to create the virtual environment.
        echo     Most likely causes:
        echo       - No write permission in this folder. Move the bot to a
        echo         simple path like C:\DokkanBot and try again.
        echo       - An "env" folder left over from another Python version.
        echo         Delete the "env" folder and relaunch.
        echo.
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created
) else (
    echo [OK] Virtual environment found
)

REM ------------------------------------------------------------
REM [4/7] Activate virtual environment
echo.
echo [4/7] Activating virtual environment...
if exist "env\Scripts\activate.bat" (
    call "env\Scripts\activate.bat"
) else (
    echo.
    echo ERROR: env\Scripts\activate.bat was not found.
    echo     The "env" folder is incomplete or was made by a different
    echo     Python. Delete the "env" folder and relaunch this script.
    echo.
    pause
    exit /b 1
)
echo [OK] Virtual environment activated

REM From here on, call the venv's Python by its ABSOLUTE PATH. On some PCs the
REM Microsoft Store "App execution alias" for python.exe hijacks the bare
REM "python" command even inside an activated venv - it prints
REM "Python was not found..." and exits with code 9009. An absolute path skips
REM that lookup entirely.
set "VENV_PY=%~dp0env\Scripts\python.exe"
if not exist "%VENV_PY%" (
    echo.
    echo ERROR: The virtual environment's Python was not found at:
    echo     "%VENV_PY%"
    echo     The "env" folder is incomplete or broken. Delete the "env" folder
    echo     and relaunch this script to rebuild it.
    echo.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM [5/7] Dependencies
echo.
echo [5/7] Checking dependencies...
if exist "requirements.txt" (
    echo Installing/updating dependencies. This can take a minute...
    "%VENV_PY%" -m pip install --upgrade pip setuptools wheel --no-warn-script-location
    "%VENV_PY%" -m pip install -r "requirements.txt" --no-warn-script-location
    if %errorlevel% neq 0 (
        echo.
        echo ERROR: Failed to install dependencies.
        echo     Most likely causes:
        echo       - No internet connection, or a firewall is blocking pip.
        echo       - Antivirus quarantined a file. Add this folder as an
        echo         exclusion, then relaunch.
        echo       - This folder is inside OneDrive and a file was locked.
        echo         Move the bot to C:\DokkanBot and try again.
        echo.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed/updated
) else (
    echo WARNING: requirements.txt not found - skipping installation.
)

REM ------------------------------------------------------------
REM [6/7] Bot launcher presence - support BOTH compiled and source layouts
echo.
echo [6/7] Checking bot launcher...
set "LAUNCHER_LAYOUT="
if exist "bot\bot_launcher.py" (
    set "LAUNCHER_LAYOUT=compiled"
    echo [OK] Bot launcher found in bot\ directory - compiled distribution
) else if exist "bot_launcher.py" (
    set "LAUNCHER_LAYOUT=source"
    echo [OK] Bot launcher found at repo root - source checkout
) else (
    echo.
    echo ERROR: bot_launcher.py was not found in "bot\" or in this folder.
    echo     Make sure you extracted the FULL .zip and are running this from
    echo     the extracted folder.
    echo.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM [7/7] Launch the bot
echo.
echo [7/7] Launching bot...
echo ========================================
echo Starting Dokkan Battle Bot...
echo ========================================
echo.
echo IMPORTANT: A Discord authorization page will open in your browser.
echo Please authorize the application to verify your tier and continue.
echo The bot will wait for you to complete the authorization...
echo.

if "%LAUNCHER_LAYOUT%"=="compiled" (
    REM Change to bot directory so main.pyd is on sys.path next to bot_launcher.py.
    REM VENV_PY is an absolute path, so it still resolves after the cd.
    cd bot
    "%VENV_PY%" bot_launcher.py
) else (
    REM Source checkout: stay at repo root; bot_launcher._resolve_main_dir
    REM will add src/ to sys.path before importing main.
    "%VENV_PY%" bot_launcher.py
)

if %errorlevel% neq 0 (
    echo.
    echo ========================================
    echo Bot exited with error code: %errorlevel%
    echo ========================================
    echo.
    echo If the bot did not start, run down this quick checklist:
    echo   1. Python is 3.12 - recommended 3.12.10. Other versions fail.
    echo   2. The bot folder is NOT inside OneDrive or a temp/zip folder.
    echo   3. You did NOT need to run as Administrator - try a normal launch.
    echo   4. Your antivirus is not blocking the folder - add an exclusion.
    echo   5. The full .zip was extracted - not run from inside the archive.
    echo   6. If you saw "Python was not found" or a Microsoft Store page:
    echo      open Windows Settings, go to Apps - Advanced app settings - App
    echo      execution aliases, and turn OFF python.exe and python3.exe. Then
    echo      install Python 3.12.10 from python.org, delete the "env" folder,
    echo      and relaunch.
    echo.
    pause
)

echo.
echo Bot session ended.
pause
endlocal
